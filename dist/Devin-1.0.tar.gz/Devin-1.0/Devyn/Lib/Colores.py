class Color:
    GREEN = '\033[92m'                                                            
    BLUE = '\033[94m'                                                             
    END = '\033[0m'                                                                
    BOLD = "\033[1m"                                                                         
    HEADER = '\033[95m'                                                             
    YELLOW = '\033[93m'                                                            
    RED = '\033[91m'
    CYAN = '\033[36m'
    PINK = '\033[35m'
