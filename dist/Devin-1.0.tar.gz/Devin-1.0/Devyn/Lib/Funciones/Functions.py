def functionHello(data):
    print("function-------> %s" %data)
#@dominio
