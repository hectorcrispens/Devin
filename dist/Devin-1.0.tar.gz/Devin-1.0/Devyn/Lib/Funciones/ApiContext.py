class ApiContext():
    def apiHello(self, name):
        print("#################################")
        print(" WELCOME TO APICONTEXT  %s  " %name)
        print("#################################")

    def apiArgs(self, args):
        print("args ->> ", args)

    def apiOptionsString(self, option_strings):
        print("option_strings ->> ", option_strings)
        
