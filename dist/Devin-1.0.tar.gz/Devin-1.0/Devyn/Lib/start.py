from Context import *
from Engine import Engine
import os
class Start():
    modules = {
        "Engine" : Engine()
        }
    def getM(self):
        return self.modules
