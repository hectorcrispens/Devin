from setuptools import setup, find_packages

setup(
name="Devin",
version="1.0",
description="",
author="Hector Crispens",
author_email="hector.or.cr@gmail.com",
url="https://github.com/hectorcrispens",
packages=find_packages()
)
